﻿string mevsim;
Console.WriteLine("Bir mevsim giriniz");
mevsim = Console.ReadLine();

if (mevsim=="ilkbahar")
{
    Console.Write("Mart,Nisan,Mayıs", mevsim);
}
else if (mevsim == "yaz")
{
    Console.Write("Haziran,Temmuz,Agustos", mevsim);
}
else if (mevsim == "sonbahar")
{
    Console.Write("Eylül,Ekim,Kasım", mevsim);
}
else if (mevsim == "kış")
{
    
        Console.Write(mevsim + " Mevsimindeki aylar Aralık Ocak Şubat");
}
else
{
    Console.Write("Hatalı giriş yaptınız");
}
Console.ReadKey();