﻿int kenar, alan, cevre;
Console.Write("Karenin Kenarını Giriniz: ");
kenar=Convert.ToInt32(Console.ReadLine());
alan = kenar * kenar;
cevre = kenar * 4;
Console.WriteLine("Alan: " + alan);
Console.WriteLine("Çevre: " + cevre);
Console.ReadLine();
