﻿string mevsim;
Console.Write("Mevsim giriniz");
mevsim = Console.ReadLine();

switch (mevsim)
{
    case "yaz":Console.WriteLine("Haziran,Temmuz,Ağustos");
            break;
    case "sonbahar":
        Console.WriteLine("Eylül,Ekim,Kasım");
            break;
    case "kış":
        Console.WriteLine("Aralık,Ocak,Şubat");
            break;
    case "ilkbahar":
        Console.WriteLine("Mart,Nisan,Mayıs");
            break;
    default:Console.WriteLine("Hatalı mevsim girişi");
        break;
}Console.ReadKey();