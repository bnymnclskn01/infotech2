﻿int sayi1, sayi2, toplama, cikarma, carpma, bolme;
Console.Write("1.sayıyı giriniz : ");
sayi1 = int.Parse(Console.ReadLine());
Console.Write("2.sayıyı giriniz : ");
sayi2 = int.Parse(Console.ReadLine());
toplama = sayi1 + sayi2;
cikarma = sayi1 - sayi2;
carpma = sayi1 * sayi2;
bolme = sayi1 / sayi2;
Console.WriteLine("Toplamı : " + toplama);
Console.WriteLine("Kalanı : " + cikarma);
Console.WriteLine("Çarpımı : " + carpma);
Console.WriteLine("Bölümü : " + bolme);

Console.ReadKey();

