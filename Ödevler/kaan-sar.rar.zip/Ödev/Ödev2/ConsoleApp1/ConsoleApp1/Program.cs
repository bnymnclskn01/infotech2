﻿double s1, s2, s3, ortalama;
Console.Write("1.Sınav Notunu Giriniz: ");
s1=Convert.ToDouble(Console.ReadLine());
Console.Write("2.Sınav Notunu Giriniz: ");
s2 = Convert.ToDouble(Console.ReadLine());
Console.Write("3.Sınav Notunu Giriniz: ");
s3 = Convert.ToDouble(Console.ReadLine());
ortalama = (s1 + s2 + s3) / 3;
Console.Write("Ortalama: " + ortalama);
Console.ReadLine();


