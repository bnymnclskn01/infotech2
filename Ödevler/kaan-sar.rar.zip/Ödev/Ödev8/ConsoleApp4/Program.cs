﻿double s1, s2, ort;
Console.Write("1.Sınav Notu:");
s1=Convert.ToDouble(Console.ReadLine());
Console.Write("2.Sınav Notu:");
s2 = Convert.ToDouble(Console.ReadLine());
ort = (s1 + s2) / 2;
Console.Write(" Ortalama : " +  ort);
if (ort>=50)
{
    Console.WriteLine(" Tebrikler Dersi Geçtiniz :)");
}
else
{
    Console.WriteLine(" Malesef Dersten Kaldınız");
}
Console.ReadKey();